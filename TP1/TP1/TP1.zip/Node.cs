﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace TP1
{
    public abstract class Node
    {
        protected Thread _thread;

        protected Parameters _parameters;

        public Parameters Params => _parameters;

        public Node(Parameters parameters)
        {
            _parameters = parameters;
            _thread = new Thread(Update);
        }

        public virtual void Start()
        {
            _thread.Start();
        }

        public abstract void Update();
    }

    public abstract class MachineNode : Node
    {
        protected bool _isEmitting = false;

        public virtual SimpleSyncedBuffer UpTransferBuffer { get; set; }

        public virtual SimpleSyncedBuffer DownTransferBuffer { get; set; }
        
        public override void Start()
        {
            base.Start();
        }

        public MachineNode(Parameters parameters, bool isEmitting) : base(parameters)
        {
            _isEmitting = isEmitting;
        }

        public override void Update()
        {
            if (_isEmitting)
            {
                Emit();
            }
            else
            {
                Receive();
            }
        }

        public virtual void Emit() { }

        public virtual void Receive() { }
    }
}

