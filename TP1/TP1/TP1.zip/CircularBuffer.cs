﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;

//using ConcurrentQueue = System.Collections.Concurrent.ConcurrentQueue<byte[]>;

namespace TP1
{
    public class CircularBuffer : SyncedBuffer
    {
        protected int _max;
        public int Max => _max;

        protected byte[] _data;
        protected int _offset;
        protected int _size;

        public bool IsFull => _size == _max;

        public bool IsEmpty => _size == 0;

        public CircularBuffer(int num, int itemSize)
        {
            _size = 0;
            _offset = 0;
            _max = num * itemSize;
            _data = new byte[_max];

            Empty_ReadyToReceive = new SemaphoreSlim(num, num);
            Full_ReadyToSend = new SemaphoreSlim(0, num);
        }

        public override void DoReceive(byte[] dest)
        {
            TryDequeue(dest.Length, dest);
        }

        public override void DoSend(byte[] values)
        {
            TryEnqueue(values);
        }

        // TODO: hide
        private bool TryEnqueue(byte[] values)
        {
            int pos = (_offset + _size).Mod(_max);

            if (pos + values.Length > _max)
            {
                int remaining = (pos + values.Length) - _max;
                int extra = values.Length - remaining;
                values.SubArray(0, values.Length - extra).CopyTo(_data, pos);
                values.SubArray(values.Length - extra, extra).CopyTo(_data, 0);
            }
            else
            {
                values.CopyTo(_data, pos);
            }

            _size += values.Length;

            return true;
        }

        private bool TryDequeue(int size, byte[] destination)
        {
            int pos = _offset; // first in line

            if (pos + size > _max)
            {
                int remaining = (pos + size) - _max;
                _data.SubArray(pos, size - remaining).CopyTo(destination, 0);
                _data.SubArray(0, remaining).CopyTo(destination, size - remaining);
            }
            else
            {
                _data.SubArray(pos, size).CopyTo(destination, 0);
            }

            _offset += size;
            _offset = _offset.Mod(_max);
            _size -= size;


            return true;
        }
    }
}
