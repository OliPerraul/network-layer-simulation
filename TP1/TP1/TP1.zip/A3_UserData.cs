﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace TP1
{
    public struct UserData
    {
        public const int Size = 16;
        public static int HeaderSize => sizeof(byte) + sizeof(byte);
        public static int ContentSize => Size - HeaderSize;

        public string String => Encoding.UTF8.GetString(Content);

        private byte isEOF;
        public bool IsEOF {
            get => Convert.ToBoolean(isEOF);
            set => isEOF = Convert.ToByte(value);
        }

        public byte OccupiedSize;
        public byte[] Content;

        public byte[] ToArray()
        {
            var stream = new MemoryStream();
            var writer = new BinaryWriter(stream);

            writer.Write(isEOF);
            writer.Write(OccupiedSize);
            writer.Write(Content);

            return stream.ToArray();
        }

        public static UserData FromArray(byte[] bytes)
        {
            var reader = new BinaryReader(new MemoryStream(bytes));

            var s = default(UserData);

            s.isEOF = reader.ReadByte();
            s.OccupiedSize = reader.ReadByte();
            s.Content = reader.ReadBytes(Convert.ToInt32(ContentSize));         

            return s;
        }
    }

    public class A3_UserData : MachineNode
    {
        public override SimpleSyncedBuffer DownTransferBuffer { get; set; } = new SimpleSyncedBuffer(UserData.Size);

        private FileStream _stream;

        private BinaryWriter _writer;

        private A2_FrameDataManipulation _a2;

        public void Set(A2_FrameDataManipulation a2)
        {
            _a2 = a2;
        }

        public A3_UserData(
            Parameters parameters,
            bool isEmitting) :
            base(
                parameters,
                isEmitting)
        { }

        public override void Start()
        {
            if (_isEmitting)
            {
                if (!File.Exists(_parameters.FullSource))
                {
                    Console.WriteLine("Error: File not found.");
                    return;
                }

                _stream = File.Open(_parameters.FullSource, FileMode.Open);
            }
            else
            {
                if (!File.Exists(_parameters.FullDestination))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(_parameters.FullDestination));
                }
                else
                {
                    File.Open(_parameters.FullDestination, FileMode.Open).Close();
                    File.Delete(_parameters.FullDestination);
                    
                }

                _writer = new BinaryWriter(File.Create(_parameters.FullDestination));
       
            }

            base.Start();
        }

        public override void Emit()
        {
            byte[] userDataBytes = new byte[UserData.Size];
            byte[] userDataContentBytes = new byte[UserData.ContentSize];
            long progress = 0;

            while (true)
            {
                // Send file by 16 byte formats
                // byte 0: is the number of meaningful byte
                // byte ^0: are content bytes                
                Array.Clear(userDataContentBytes, 0, userDataContentBytes.Length);
                int read;
                if ((read = _stream.Read(
                    userDataContentBytes,
                    0,
                    UserData.ContentSize)) > 0)
                {
                    progress += read;

                    Array.Clear(userDataBytes, 0, userDataBytes.Length);
                    userDataContentBytes.CopyTo(userDataBytes, UserData.HeaderSize);
                    userDataBytes[0] = Convert.ToByte(progress == _stream.Length);
                    userDataBytes[1] = Convert.ToByte(read);

                    DownTransferBuffer.Send(userDataBytes);
                }
                else
                {
                    Console.WriteLine("Finished Reading..");
                    break;
                }
            }

        }

        public override void Receive()
        {
            byte[] userDataBytes = new byte[UserData.Size];
            while (true)
            {
                Array.Clear(userDataBytes, 0, userDataBytes.Length);
                _a2.UpTransferBuffer.Receive(userDataBytes);
                var userData = UserData.FromArray(userDataBytes);

                _writer.Write(userData.Content, 0, Convert.ToInt32(userData.OccupiedSize));
                _writer.Flush();

                if (userData.IsEOF)
                {               
                    _writer.Close();
                    Console.WriteLine("Finished Writing..");
                    Environment.Exit(1);

                    break;
                }
            }

        }
    }
}
