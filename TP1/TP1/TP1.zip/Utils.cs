﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;

namespace TP1
{
    public static class Utils
    {
        public static string CurrentDirectory => Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
    }

    public static class Extensions
    {
        public static T[] SubArray<T>(this T[] data, int index, int length)
        {
            T[] result = new T[length];
            Array.Copy(data, index, result, 0, length);
            //bool isEqual = Enumerable.SequenceEqual(data, result);
            return result;
        }      

        public static int Mod(this int x, int m)
        {
            return (x % m + m) % m;
        }
    }

    public enum ErrorChangeType
    {
        D_NoError,
        A_AllFrames,
        B_RandomFrames,
        C_SpecifiedFrames
    }

    public enum HammingMode
    {
        Corrector,
        Detector
    }

}
