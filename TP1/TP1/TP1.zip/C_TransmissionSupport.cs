﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace TP1
{
    public class C_TransmissionSupport : Node
    {
        private CircularBuffer _inputBuffer { get; set; }
        private CircularBuffer _outputBuffer { get; set; }

        private Random _random;

        public const int ErrorChance = 50;

        public C_TransmissionSupport(Parameters parameters) : base(parameters)
        {
            _inputBuffer = new CircularBuffer(parameters.ThreadBufferSize, A1_FrameSupport.FrameSupportSize);
            _outputBuffer = new CircularBuffer(parameters.ThreadBufferSize, A1_FrameSupport.FrameSupportSize);
            _random = new Random((int)DateTime.UtcNow.Ticks);
        }

        public void Send(byte[] values)
        {
            _inputBuffer.Send(values);
        }

        public void Receive(byte[] dest)
        {
            _outputBuffer.Receive(dest);
        }

        public override void Start()
        {
            base.Start();
        }

        public void IntroduceError(byte[] frameSupportBytes, byte[] simulateErrorBytes)
        {
            frameSupportBytes.CopyTo(simulateErrorBytes, 0);

            foreach (int i in _parameters.BitErrorPositions)
            {
                int j = i / 8;
                simulateErrorBytes[j] = (byte)(frameSupportBytes[j] ^ (1 << (i % 8)));
            }

            Console.WriteLine("ORIGINAL:");
            Console.WriteLine(BitConverter.ToString(frameSupportBytes));
            Console.WriteLine("ERROR "+ string.Join(',', _parameters.BitErrorPositions)+":");
            Console.WriteLine(BitConverter.ToString(simulateErrorBytes));
        }

        public override void Update()
        {
            var frameSupportBytes = new byte[A1_FrameSupport.FrameSupportSize];
            var simulateErrorBytes = new byte[A1_FrameSupport.FrameSupportSize];
            while (true)
            {
                // Simulate thread latency
                Thread.Sleep(_parameters.ThreadBufferDelay);
                Array.Clear(frameSupportBytes, 0, frameSupportBytes.Length);                
                _inputBuffer.Receive(frameSupportBytes);

                // Simulate errors
                switch (_parameters.ErrorChangeType)
                {
                    case ErrorChangeType.D_NoError:
                        break;

                    case ErrorChangeType.A_AllFrames:
                        IntroduceError(frameSupportBytes, simulateErrorBytes);
                        break;

                    case ErrorChangeType.B_RandomFrames:
                        int percent = _random.Next(0, 100);
                        if(percent < ErrorChance) IntroduceError(frameSupportBytes, simulateErrorBytes);      
                        break;

                    case ErrorChangeType.C_SpecifiedFrames:
                        int id = Frame.FromArray(frameSupportBytes.SubArray(0, Frame.Size)).ID;
                        foreach (var frame in _parameters.FramesToChange)
                        {
                            if (frame == id)
                            {
                                IntroduceError(frameSupportBytes, simulateErrorBytes);
                                break;
                            }
                        }

                        break;
                }

                _outputBuffer.Send(frameSupportBytes);
            }
        }
    }
}
