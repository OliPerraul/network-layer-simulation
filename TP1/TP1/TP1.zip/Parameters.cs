﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace TP1
{
    public class Parameters
    {
        public string Source { get; set; }

        public string FullSource => Path.Combine(Utils.CurrentDirectory, Source);

        public string Destination { get; set; }

        public string FullDestination => Path.Combine(Utils.CurrentDirectory, Destination);

        public int[] BitErrorPositions { get; set; }

        public ErrorChangeType ErrorChangeType { get; set; }

        public int[] FramesToChange { get; set; }

        public int ThreadBufferSize { get; set; }

        public int ThreadBufferDelay { get; set; }

        public int WinSizeA { get; set; }

        public int WinSizeB { get; set; }

        public int TimeOutA { get; set; }

        public int TimeOutB { get; set; }

        public HammingMode HammingMode { get; set; }

        public char EmittingMachine { get; set; }

        public static bool TryDeserialize(
            string file,
            out Parameters parameters)
        {
            parameters = new Parameters();

            StreamReader streamReader = new StreamReader(file);

            string line = "";
            if (!((line = streamReader.ReadLine()) != null))
                return false;

            parameters.Source = line;

            if (!((line = streamReader.ReadLine()) != null))
                return false;

            parameters.Destination = line;

            if (!((line = streamReader.ReadLine()) != null))
                return false;

            try
            {
                List<string> split = !line.Any(char.IsDigit) ? new List<string>() : line.Split(",").ToList();
                parameters.BitErrorPositions = split.Count == 0 ?
                    new int[0] :
                    split.Select(x => int.Parse(x)).ToArray();
            }
            catch (Exception e)
            {
                return false;
            }

            if (!((line = streamReader.ReadLine()) != null))
                return false;

            if (line == "A") parameters.ErrorChangeType = ErrorChangeType.A_AllFrames;
            else if (line == "B") parameters.ErrorChangeType = ErrorChangeType.B_RandomFrames;
            else if (line == "C") parameters.ErrorChangeType = ErrorChangeType.C_SpecifiedFrames;
            else if (line == "D") parameters.ErrorChangeType = ErrorChangeType.D_NoError;
            else return false;

            if (!((line = streamReader.ReadLine()) != null))
                return false;
            try
            {
                List<string> split = !line.Any(char.IsDigit) ? new List<string>() : line.Split(",").ToList();
                parameters.FramesToChange = split.Count == 0 ?
                    new int[0] :
                    split.Select(x => int.Parse(x)).ToArray();
            }
            catch (Exception e)
            {
                return false;
            }

            if (!((line = streamReader.ReadLine()) != null))
                return false;

            try
            {
                parameters.ThreadBufferSize = int.Parse(line);
            }
            catch
            {
                return false;
            }

            if (!((line = streamReader.ReadLine()) != null))
                return false;

            try
            {
                parameters.ThreadBufferDelay = int.Parse(line);
            }
            catch
            {
                return false;
            }


            if (!((line = streamReader.ReadLine()) != null))
                return false;

            try
            {
                parameters.WinSizeA = int.Parse(line);
            }
            catch
            {
                return false;
            }


            if (!((line = streamReader.ReadLine()) != null))
                return false;

            try
            {
                parameters.WinSizeB = int.Parse(line);
            }
            catch
            {
                return false;
            }

            if (!((line = streamReader.ReadLine()) != null))
                return false;

            try
            {
                parameters.TimeOutA = int.Parse(line);
            }
            catch
            {
                return false;
            }

            if (!((line = streamReader.ReadLine()) != null))
                return false;

            try
            {
                parameters.TimeOutB = int.Parse(line);
            }
            catch
            {
                return false;
            }

            if (!((line = streamReader.ReadLine()) != null))
                return false;

            if (line == "D") parameters.HammingMode = HammingMode.Detector;
            else if (line == "R") parameters.HammingMode = HammingMode.Corrector;
            else return false;

            if (!((line = streamReader.ReadLine()) != null))
                return false;

            if (line == "A") parameters.EmittingMachine = 'A';
            else if (line == "B") parameters.EmittingMachine = 'B';
            else return false;

            return true;
        }
    }
}
