﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace TP1
{
    public abstract class SyncedBuffer
    {
        public Mutex _mutex = new Mutex();

        // Empty: buffer is empty and ready to receive
        public virtual SemaphoreSlim Empty_ReadyToReceive { get; set; } = null;

        // Full: buffer is full
        //buffer hasnt been filled yet
        public virtual SemaphoreSlim Full_ReadyToSend { get; set; } = null;

        public void Receive(byte[] dest)
        {
            // Waiting until full
            Full_ReadyToSend.Wait();
            _mutex.WaitOne();

            DoReceive(dest);

            _mutex.ReleaseMutex();
            Empty_ReadyToReceive.Release();
        }

        public void Send(byte[] values)
        {
            // Waiting until empty
            Empty_ReadyToReceive.Wait();
            _mutex.WaitOne();

            DoSend(values);

            _mutex.ReleaseMutex();
            Full_ReadyToSend.Release();
        }

        public virtual void DoReceive(byte[] dest)
        {

        }

        public virtual void DoSend(byte[] dest)
        {

        }

    }


    // Utility for producer consumer problem
    public class SimpleSyncedBuffer : SyncedBuffer
    {
        public override SemaphoreSlim Empty_ReadyToReceive { get; set; } = new SemaphoreSlim(1, 1);

        // Full: buffer is full
        //buffer hasnt been filled yet
        public override SemaphoreSlim Full_ReadyToSend { get; set; } = new SemaphoreSlim(0, 1);

        private byte[] _data;

        public byte[] Data => _data;

        public SimpleSyncedBuffer(int size)
        {
            _data = new byte[size];
        }

        public override void DoReceive(byte[] dest)
        {
            _data.CopyTo(dest, 0);
        }

        public override void DoSend(byte[] values)
        {
            values.CopyTo(_data, 0);            
        }
    }
}
