﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace TP1
{
    public enum FrameType : byte
    {
        Data,
        EndOfTransmission,
        NAK,
        ACK,
    }

    public struct Frame
    {
        public const int Size = 64;

        public static int HeaderSize =>
            sizeof(int) +
            sizeof(FrameType) +
            sizeof(int);

        public static int ContentSize =>
                Size - HeaderSize;

        public string String => Encoding.UTF8.GetString(Content);

        public int ID;
        public FrameType Type;
        public int OccupiedSize;
        public byte[] Content;

        public byte[] ToArray()
        {
            var stream = new MemoryStream();
            var writer = new BinaryWriter(stream);

            writer.Write(ID);
            writer.Write((byte)Type);
            writer.Write(OccupiedSize);
            writer.Write(Content);

            writer.Flush();
            return stream.ToArray();
        }

        public static Frame FromArray(byte[] bytes)
        {
            var reader = new BinaryReader(new MemoryStream(bytes));

            var s = default(Frame);
            s.ID = reader.ReadInt32();
            s.Type = (FrameType)reader.ReadByte();
            s.OccupiedSize = reader.ReadInt32();
            s.Content = reader.ReadBytes(ContentSize);

            return s;
        }
    }

    public class A2_FrameDataManipulation : MachineNode
    {
        private A1_FrameSupport _a1;

        private A3_UserData _a3;       

        public A2_FrameDataManipulation(Parameters parameters, bool isEmitting) : base(parameters, isEmitting) { }

        public override SimpleSyncedBuffer UpTransferBuffer { get; set; } = new SimpleSyncedBuffer(UserData.Size);

        public override SimpleSyncedBuffer DownTransferBuffer { get; set; } = new SimpleSyncedBuffer(Frame.Size);

        public void Set(A1_FrameSupport a1, A3_UserData a3)
        {
            _a1 = a1;
            _a3 = a3;
        }

        public override void Start()
        {
            base.Start();
        }

        public override void Receive()
        {
            var frameBytes = new byte[Frame.Size];
            var frame = new Frame
            {
                ID = 0,
                Content = new byte[Frame.ContentSize],
                OccupiedSize = 0,
                Type = FrameType.Data
            };

            var userDataBytes = new byte[UserData.Size];
            var userData = new UserData
            {                
                OccupiedSize = 0,
                IsEOF = false,
                Content = new byte[UserData.ContentSize]
            };

            // Get first frame
            int currentFrameProgress = 0;
            Array.Clear(frameBytes, 0, frameBytes.Length);
            _a1.UpTransferBuffer.Receive(frameBytes);            
            frame = Frame.FromArray(frameBytes);

            while (true)
            {

                // Get next frames
                if (currentFrameProgress >= frame.OccupiedSize)
                {
                    currentFrameProgress = 0;
                    Array.Clear(frameBytes, 0, frameBytes.Length);
                    _a1.UpTransferBuffer.Receive(frameBytes);
                    frame = Frame.FromArray(frameBytes);
                }

                // If last userdata of lastframe, then user data is not full ocuppied
                userData.OccupiedSize = (byte)
                    ((currentFrameProgress + UserData.ContentSize >= frame.OccupiedSize &&
                    frame.Type == FrameType.EndOfTransmission) ?
                        frame.OccupiedSize - currentFrameProgress :
                        UserData.ContentSize);

                Array.Clear(userData.Content, 0, userData.Content.Length);
                frame.Content
                    .SubArray(
                    currentFrameProgress,
                    userData.OccupiedSize)
                    .CopyTo(userData.Content, 0);

                userData.IsEOF =
                        currentFrameProgress + UserData.ContentSize >= frame.OccupiedSize &&
                        frame.Type == FrameType.EndOfTransmission;

                UpTransferBuffer.Send(userData.ToArray());                

                if (userData.IsEOF)
                {
                    break;
                }

                currentFrameProgress += UserData.ContentSize;
            }
        }

        public override void Emit()
        {
            var frameBuffer = new byte[Frame.Size];
            var frame = new Frame
            {
                ID = 0,
                Content = new byte[Frame.ContentSize],
                OccupiedSize = 0,
                Type = FrameType.Data
            };

            var userDataBuffer = new byte[UserData.Size];
            var userData = new UserData
            {
                OccupiedSize = 0,
                IsEOF = false,
                Content = new byte[UserData.ContentSize]
            };

            while (true)
            {

                if (frame.OccupiedSize + UserData.ContentSize >= Frame.ContentSize ||
                    frame.Type == FrameType.EndOfTransmission)
                {
                    DownTransferBuffer.Send(frame.ToArray());

                    if (frame.Type == FrameType.EndOfTransmission)
                    {
                        break;
                    }

                    frame.OccupiedSize = 0;
                    frame.ID++;
                    Array.Clear(frame.Content, 0, frame.Content.Length);
                }

                // Wait for full
                Array.Clear(userDataBuffer, 0, userDataBuffer.Length);
                _a3.DownTransferBuffer.Receive(userDataBuffer);            
                userData = UserData.FromArray(userDataBuffer);

                userData.Content
                    .SubArray(0, userData.OccupiedSize)
                    .CopyTo(frame.Content, frame.OccupiedSize);                

                frame.OccupiedSize += userData.OccupiedSize;

                // If finished reading we have set the first byte to the amount read
                // mark as end of transmission
                frame.Type = userData.OccupiedSize < UserData.ContentSize ?
                    FrameType.EndOfTransmission :
                    FrameType.Data;
            }
        }
    }
}
