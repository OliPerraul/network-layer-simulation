﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TP1
{
    public class A1_FrameSupport : MachineNode
    {
        private A2_FrameDataManipulation _a2;
        private C_TransmissionSupport _c;

        public const int FrameSupportSize = 128;

        public override SimpleSyncedBuffer UpTransferBuffer { get; set; } = new SimpleSyncedBuffer(Frame.Size);

        public A1_FrameSupport(Parameters parameters, bool isEmitting) : base(parameters, isEmitting) { }

        public void Set(
            A2_FrameDataManipulation a2,
            C_TransmissionSupport c)
        {
            _a2 = a2;
            _c = c;
        }

        public override void Start()
        {
            base.Start();
        }

        // Padding added -> we will eventually added Hamming code..
        public override void Emit()
        {
            var frameBytes = new byte[Frame.Size];
            var frameSupportBytes = new byte[FrameSupportSize];
           
            while (true)
            {

                _a2.DownTransferBuffer.Receive(frameBytes);
                frameBytes.CopyTo(frameSupportBytes, 0);
                _c.Send(frameSupportBytes);
            }
        }

        public override void Receive()
        {
            var frameBytes = new byte[Frame.Size];
            var frameSupportBytes = new byte[FrameSupportSize];
            while (true)
            {

                _c.Receive(frameSupportBytes);  
                frameSupportBytes.SubArray(0, Frame.Size).CopyTo(frameBytes, 0);
                UpTransferBuffer.Send(frameBytes);
            }
        }
    }
}
